package com.desbloqueate.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Fondo = Color(0xFF090014)
private val Cian = Color(0xFF00F5FF)
private val Rosa = Color(0xFFFF2BD6)
private val Amarillo = Color(0xFFFFE45E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                JuegoScreen()
            }
        }
    }
}

@Composable
private fun JuegoScreen() {
    val columnas = 10
    val filas = 18
    var tablero by remember { mutableStateOf(List(filas) { List(columnas) { 0 } }) }
    var puntos by remember { mutableIntStateOf(0) }
    var piezaX by remember { mutableIntStateOf(4) }
    var piezaY by remember { mutableIntStateOf(0) }
    var pieza by remember { mutableStateOf(listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1)) }
    var colorPieza by remember { mutableStateOf(1) }
    var pausado by remember { mutableStateOf(false) }

    fun nuevaPieza() {
        pieza = when (Random.nextInt(4)) {
            0 -> listOf(0 to 0, 1 to 0, 2 to 0, 1 to 1)
            1 -> listOf(0 to 0, 0 to 1, 0 to 2, 1 to 2)
            2 -> listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1)
            else -> listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1)
        }
        piezaX = 3
        piezaY = 0
        colorPieza = Random.nextInt(1, 4)
    }

    fun fijarPieza() {
        val nuevo = tablero.map { it.toMutableList() }.toMutableList()
        pieza.forEach { (dx, dy) ->
            val x = piezaX + dx
            val y = piezaY + dy
            if (y in 0 until filas && x in 0 until columnas) nuevo[y][x] = colorPieza
        }
        val limpias = nuevo.filter { fila -> fila.any { it == 0 } }
        val borradas = filas - limpias.size
        val relleno = List(borradas) { MutableList(columnas) { 0 } }
        tablero = (relleno + limpias).map { it.toList() }
        puntos += borradas * 100
        nuevaPieza()
    }

    fun bajar() {
        if (pausado) return
        val puede = pieza.all { (dx, dy) ->
            val x = piezaX + dx
            val y = piezaY + dy + 1
            y < filas && x in 0 until columnas && tablero[y][x] == 0
        }
        if (puede) piezaY++ else fijarPieza()
    }

    fun mover(dx: Int) {
        if (pausado) return
        val puede = pieza.all { (px, py) ->
            val x = piezaX + px + dx
            val y = piezaY + py
            x in 0 until columnas && y in 0 until filas && tablero[y][x] == 0
        }
        if (puede) piezaX += dx
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Fondo).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("DESBLOQUÉATE", color = Cian, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("ROMPE BLOQUES · NIVEL 1", color = Rosa, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Text("PUNTOS  $puntos", color = Amarillo, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Canvas(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF120A24), RoundedCornerShape(12.dp)).padding(8.dp)
        ) {
            val celda = minOf(size.width / columnas, size.height / filas)
            val ancho = celda * columnas
            val alto = celda * filas
            val inicioX = (size.width - ancho) / 2f
            val inicioY = (size.height - alto) / 2f
            for (y in 0 until filas) for (x in 0 until columnas) {
                val color = when (tablero[y][x]) {
                    1 -> Cian
                    2 -> Rosa
                    3 -> Amarillo
                    else -> Color(0xFF241A36)
                }
                drawRect(color, Offset(inicioX + x * celda + 1, inicioY + y * celda + 1),
                    androidx.compose.ui.geometry.Size(celda - 2, celda - 2))
            }
            pieza.forEach { (dx, dy) ->
                val x = piezaX + dx
                val y = piezaY + dy
                if (x in 0 until columnas && y in 0 until filas) {
                    val color = when (colorPieza) { 1 -> Cian; 2 -> Rosa; else -> Amarillo }
                    drawRect(color, Offset(inicioX + x * celda + 1, inicioY + y * celda + 1),
                        androidx.compose.ui.geometry.Size(celda - 2, celda - 2))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { mover(-1) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Rosa)) { Text("◀") }
            Button(onClick = { bajar() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Cian, contentColor = Fondo)) { Text("BAJAR") }
            Button(onClick = { mover(1) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Rosa)) { Text("▶") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { pausado = !pausado }, modifier = Modifier.weight(1f)) { Text(if (pausado) "SEGUIR" else "PAUSA") }
            Button(onClick = {
                tablero = List(filas) { List(columnas) { 0 } }
                puntos = 0
                pausado = false
                nuevaPieza()
            }, modifier = Modifier.weight(1f)) { Text("REINICIAR") }
        }
        Spacer(Modifier.height(6.dp))
        Text("Prototipo inicial · Próximamente nuevos modos y recompensas", color = Color.LightGray, fontSize = 10.sp)
    }
}
